# HelloWorld server example

* Displays various request info.
* Sets response headers and cookies.
* Supports transparent compression.

# How to build

```
make
```

# How to run

```
./helloworldserver -addr=tcp.addr.to.listen:to
```
